export async function onRequestPost(context) {
  const { request, env } = context;
  const contentType = request.headers.get("content-type") || "";
  let data = {};
  try {
    if (contentType.includes("application/json")) {
      data = await request.json();
    } else {
      const form = await request.formData();
      data = Object.fromEntries(form);
    }
  } catch (e) {
    return new Response("Invalid form payload", { status: 400 });
  }

  const required = ["name", "email", "project", "budget", "timeline", "details"];
  for (const f of required) {
    if (!data[f] || String(data[f]).trim() === "") {
      return new Response(`Missing field: ${f}`, { status: 400 });
    }
  }

  const now = new Date().toISOString();
  const clientIp = request.headers.get("CF-Connecting-IP") || null;
  const record = { ...data, ts: now, ip: clientIp };

  if (env.QUOTES && env.QUOTES.put) {
    const key = `quote:${Date.now()}:${(crypto.randomUUID && crypto.randomUUID()) || Math.random().toString(36).slice(2)}`;
    try { await env.QUOTES.put(key, JSON.stringify(record)); } catch (e) {}
  }

  if (env.BREVO_API_KEY && env.TO_EMAIL && env.FROM_EMAIL) {
    const html = `
      <h3>New Quote Request</h3>
      <p><b>Name:</b> ${escapeHtml(data.name)}</p>
      <p><b>Email:</b> ${escapeHtml(data.email)}</p>
      <p><b>Project:</b> ${escapeHtml(data.project)}</p>
      <p><b>Budget:</b> ${escapeHtml(data.budget)}</p>
      <p><b>Timeline:</b> ${escapeHtml(data.timeline)}</p>
      <p><b>Details:</b><br/>${escapeHtml(data.details).replace(/\n/g, "<br/>")}</p>
      <p style="color:#888">IP: ${clientIp || "n/a"} • ${now}</p>
    `;
    const payload = {
      sender: { email: env.FROM_EMAIL, name: "MAKO Intake" },
      to: [{ email: env.TO_EMAIL }],
      subject: `New Quote Request — ${data.project} — ${data.name}`,
      htmlContent: html
    };
    try {
      await fetch("https://api.brevo.com/v3/smtp/email", {
        method: "POST",
        headers: { "api-key": env.BREVO_API_KEY, "content-type": "application/json" },
        body: JSON.stringify(payload)
      });
    } catch (e) {}
  }

  const thankUrl = env.THANK_YOU_URL || "/thank-you.html";
  return Response.redirect(thankUrl, 302);
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
